// Service Worker для SecurePass
const CACHE_NAME = 'securepass-v2.0';
const APP_VERSION = '2.0.0';

// Файлы для кеширования (только основные, без иконок)
const urlsToCache = [
  './',
  './index.html',
  './style.css',
  './script.js',
  './manifest.json'
];

// Установка Service Worker
self.addEventListener('install', event => {
  console.log('🔧 Service Worker: Установка v' + APP_VERSION);
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('📦 Кеширование основных ресурсов...');
        // Кешируем только основные файлы
        return cache.addAll(urlsToCache)
          .then(() => {
            console.log('✅ Основные ресурсы закешированы');
            return self.skipWaiting();
          })
          .catch(error => {
            console.warn('⚠️ Не все ресурсы удалось закешировать:', error);
            // Продолжаем даже с ошибками
            return self.skipWaiting();
          });
      })
  );
});

// Активация Service Worker
self.addEventListener('activate', event => {
  console.log('⚡ Service Worker: Активация...');
  
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log(`🗑️ Удаление старого кеша: ${cacheName}`);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('✅ Service Worker активирован');
      return self.clients.claim();
    })
  );
});

// Стратегия кеширования: сначала кеш, потом сеть
self.addEventListener('fetch', event => {
  // Пропускаем не-GET запросы
  if (event.request.method !== 'GET') return;
  
  // Пропускаем chrome-extension://
  if (event.request.url.startsWith('chrome-extension://')) return;
  
  // Пропускаем данные
  if (event.request.url.includes('/data')) return;
  
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Возвращаем из кеша если есть
        if (response) {
          return response;
        }
        
        // Иначе загружаем из сети
        return fetch(event.request)
          .then(response => {
            // Проверяем валидность ответа
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Не кешируем внешние ресурсы
            if (!event.request.url.startsWith('http://localhost') && 
                !event.request.url.startsWith('http://127.0.0.1')) {
              return response;
            }
            
            // Клонируем ответ для кеширования
            const responseToCache = response.clone();
            
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
            
            return response;
          })
          .catch(error => {
            console.log('🌐 Офлайн режим для:', event.request.url);
            
            // Для HTML страниц возвращаем главную страницу
            if (event.request.headers.get('accept').includes('text/html')) {
              return caches.match('./index.html');
            }
            
            return new Response('Офлайн', {
              status: 408,
              headers: { 'Content-Type': 'text/plain' }
            });
          });
      })
  );
});

// Обработка сообщений от клиента
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    console.log('🔄 Пропуск ожидания Service Worker');
    self.skipWaiting();
  }
});