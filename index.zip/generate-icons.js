const fs = require('fs');
const { createCanvas } = require('canvas');

// Основные размеры для PWA
const pwaSizes = [72, 96, 128, 144, 152, 192, 384, 512];
// Размеры для Windows tiles
const msTileSizes = [
  { width: 70, height: 70 },
  { width: 150, height: 150 },
  { width: 310, height: 310 },
  { width: 310, height: 150 },
  { width: 144, height: 144 }
];

// Создаем папку icons если её нет
if (!fs.existsSync('icons')) {
  fs.mkdirSync('icons', { recursive: true });
}

// Функция для рисования скругленного прямоугольника
function roundRect(ctx, x, y, width, height, radius) {
  if (radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillRect(x, y, width, height);
  }
}

// Функция для создания иконки с логотипом
function createIcon(size, isSquare = true) {
  const width = isSquare ? size : size.width;
  const height = isSquare ? size : size.height;
  
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Градиентный фон
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, '#2196f3');
  gradient.addColorStop(1, '#1976d2');
  
  // Фон
  ctx.fillStyle = gradient;
  roundRect(ctx, 0, 0, width, height, Math.min(width, height) * 0.2);
  
  // Иконка щита (только для больших размеров)
  if (Math.min(width, height) > 32) {
    const centerX = width / 2;
    const centerY = height / 2;
    const iconSize = Math.min(width, height) * 0.6;
    
    // Щит
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - iconSize * 0.3);
    ctx.bezierCurveTo(
      centerX + iconSize * 0.25, centerY - iconSize * 0.3,
      centerX + iconSize * 0.3, centerY - iconSize * 0.1,
      centerX + iconSize * 0.2, centerY + iconSize * 0.2
    );
    ctx.lineTo(centerX, centerY + iconSize * 0.3);
    ctx.lineTo(centerX - iconSize * 0.2, centerY + iconSize * 0.2);
    ctx.bezierCurveTo(
      centerX - iconSize * 0.3, centerY - iconSize * 0.1,
      centerX - iconSize * 0.25, centerY - iconSize * 0.3,
      centerX, centerY - iconSize * 0.3
    );
    ctx.closePath();
    ctx.fill();
    
    // Замочек
    const lockHeight = iconSize * 0.25;
    const lockWidth = iconSize * 0.35;
    
    ctx.fillStyle = '#1976d2';
    roundRect(
      ctx,
      centerX - lockWidth / 2,
      centerY - lockHeight / 2,
      lockWidth,
      lockHeight,
      lockWidth * 0.15
    );
  }
  
  return canvas;
}

// Создаем иконки
try {
  console.log('🎨 Создание иконок...');
  
  // Создаем PWA иконки
  pwaSizes.forEach(size => {
    const canvas = createIcon(size);
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(`icons/icon-${size}x${size}.png`, buffer);
    console.log(`✅ Создана иконка ${size}x${size}`);
  });

  // Создаем favicon иконки (используем те же размеры, что есть в PWA)
  console.log('\n🎨 Создание favicon иконок...');
  const faviconSizes = [16, 32, 180];
  faviconSizes.forEach(size => {
    const canvas = createIcon(size);
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(`icons/icon-${size}x${size}.png`, buffer);
    console.log(`✅ Создана favicon ${size}x${size}`);
  });

  // Создаем favicon.ico (самый маленький размер для совместимости)
  const faviconCanvas = createIcon(32);
  const faviconBuffer = faviconCanvas.toBuffer('image/png');
  fs.writeFileSync('favicon.ico', faviconBuffer);
  console.log('✅ Создана favicon.ico');

  // Создаем иконки для Windows
  console.log('\n🎨 Создание Windows иконок...');
  msTileSizes.forEach((size, index) => {
    const canvas = createIcon(size, false);
    const buffer = canvas.toBuffer('image/png');
    const name = size.width === size.height ? 
      `mstile-${size.width}x${size.height}` : 
      `mstile-${size.width}x${size.height}`;
    fs.writeFileSync(`icons/${name}.png`, buffer);
    console.log(`✅ Создана Windows иконка ${size.width}x${size.height}`);
  });

  // Создаем SVG иконку
  console.log('\n🎨 Создание SVG иконки...');
  const svgIcon = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#2196f3"/>
      <stop offset="100%" stop-color="#1976d2"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="100" fill="url(#gradient)"/>
  <path d="M256,176 Q320,176 352,224 L256,336 L160,224 Q192,176 256,176Z" fill="white" fill-opacity="0.9"/>
  <rect x="208" y="224" width="96" height="48" rx="12" fill="#1976d2"/>
</svg>`;
  fs.writeFileSync('icons/icon.svg', svgIcon);
  console.log('✅ Создана SVG иконка');

  console.log('\n✨ Все иконки успешно созданы!');
} catch (error) {
  console.error('❌ Ошибка при создании иконок:', error);
  process.exit(1);
}