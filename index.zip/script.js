// Основной объект приложения
const SecurePass = {
    config: {
        version: '2.0',
        encryption: 'AES-256',
        maxPasswords: 1000,
        defaultLength: 12,
        strengthWeights: {
            length: 0.3,
            complexity: 0.4,
            entropy: 0.3
        }
    },
    
    data: {
        passwords: [],
        settings: {
            autoCopy: false,
            autoSave: true,
            showStrength: true,
            theme: 'dark'
        },
        stats: {
            generated: 0,
            saved: 0,
            copied: 0
        }
    },
    
    state: {
        currentPassword: '',
        selectedPassword: null,
        searchTerm: '',
        sortBy: 'date',
        sortOrder: 'desc'
    },
    
    // Инициализация приложения
    async init() {
        console.log('🚀 SecurePass v2.0 инициализируется...');
        
        try {
            // Загрузка данных
            await this.loadData();
            
            // Настройка приложения
            this.setupUI();
            this.setupEventListeners();
            this.createParticles();
            
            // Генерация первого пароля
            this.generatePassword();
            this.updateStats();
            
            // Запуск анимаций
            this.startAnimations();
            
            // Инициализация PWA
            await this.initPWA();
            
            console.log('✅ SecurePass готов к работе!');
            this.showNotification('Готов к работе!', 'SecurePass успешно инициализирован', 'success');
        } catch (error) {
            console.error('❌ Ошибка инициализации:', error);
            this.showNotification('Ошибка инициализации', 'Проверьте консоль для деталей', 'error');
        }
    },
    
    // Проверка обновлений приложения
    async checkForUpdates() {
        try {
            if ('serviceWorker' in navigator) {
                const registration = await navigator.serviceWorker.getRegistration();
                
                if (registration) {
                    await registration.update();
                    
                    if (registration.waiting) {
                        this.showNotification(
                            'Доступно обновление',
                            'Новая версия SecurePass доступна. Перезагрузите для обновления.',
                            'info'
                        );
                        this.showUpdatePrompt();
                    }
                }
            }
        } catch (error) {
            console.log('⚠️ Ошибка проверки обновлений:', error);
        }
    },
    
    // Инициализация PWA
    async initPWA() {
        try {
            // Проверяем поддержку Service Worker
            if ('serviceWorker' in navigator) {
                try {
                    const registration = await navigator.serviceWorker.register('./sw.js', {
                        scope: './',
                        updateViaCache: 'none'
                    });
                    
                    console.log('✅ Service Worker зарегистрирован:', registration.scope);
                    
                    // Отслеживаем обновления Service Worker
                    registration.addEventListener('updatefound', () => {
                        const newWorker = registration.installing;
                        if (newWorker) {
                            newWorker.addEventListener('statechange', () => {
                                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                    this.showNotification('Доступно обновление', 'Перезагрузите страницу для обновления приложения', 'info');
                                }
                            });
                        }
                    });
                    
                    // Проверяем, запущено ли приложение как PWA
                    this.checkPWAStatus();
                } catch (swError) {
                    console.warn('⚠️ Service Worker не зарегистрирован:', swError);
                }
            }
            
            // Установка PWA
            this.setupPWAInstall();
            
            // Отслеживание онлайн/офлайн статуса
            this.setupNetworkStatus();
            
            // Периодическая проверка обновлений
            await this.checkForUpdates();
            
        } catch (error) {
            console.error('❌ Ошибка инициализации PWA:', error);
        }
    },
    
    // Показать запрос на обновление
    showUpdatePrompt() {
        const notification = document.createElement('div');
        notification.className = 'notification update-notification';
        notification.innerHTML = `
            <i class="fas fa-sync-alt"></i>
            <div class="notification-content">
                <div class="notification-title">Доступно обновление</div>
                <div class="notification-message">Новая версия SecurePass. Перезагрузить сейчас?</div>
                <div class="notification-actions">
                    <button class="btn-secondary btn-small" id="update-later">Позже</button>
                    <button class="btn-primary btn-small" id="update-now">Обновить</button>
                </div>
            </div>
        `;
        
        const container = document.getElementById('notification-container');
        if (container) {
            container.appendChild(notification);
            
            // Обработчики кнопок
            document.getElementById('update-now').addEventListener('click', () => {
                if ('serviceWorker' in navigator) {
                    navigator.serviceWorker.getRegistration().then(registration => {
                        if (registration && registration.waiting) {
                            registration.waiting.postMessage({ type: 'SKIP_WAITING' });
                        }
                    });
                }
                window.location.reload();
            });
            
            document.getElementById('update-later').addEventListener('click', () => {
                notification.remove();
            });
        }
    },
    
    // Проверка статуса PWA
    checkPWAStatus() {
        const isPWA = window.matchMedia('(display-mode: standalone)').matches || 
                      window.navigator.standalone ||
                      (window.matchMedia('(display-mode: fullscreen)').matches);
        
        if (isPWA) {
            console.log('📱 Приложение запущено как PWA');
            const pwaStatus = document.getElementById('pwaStatus');
            if (pwaStatus) {
                pwaStatus.innerHTML = '<i class="fas fa-mobile-alt"></i> Установленное приложение';
                pwaStatus.style.display = 'inline-block';
            }
            this.hideInstallBanner();
        } else {
            const pwaStatus = document.getElementById('pwaStatus');
            if (pwaStatus) {
                pwaStatus.style.display = 'none';
            }
        }
    },
    
    // Настройка установки PWA
    setupPWAInstall() {
        let deferredPrompt;
        const installBanner = document.getElementById('pwaInstallBanner');
        const installAppBtn = document.getElementById('installAppBtn');
        const installBtnManual = document.getElementById('installBtnManual');
        const dismissBtn = document.getElementById('dismissInstallBtn');
        
        // Скрываем баннер по умолчанию
        if (installBanner) {
            this.hideInstallBanner();
        }
        
        // Отслеживаем событие beforeinstallprompt
        window.addEventListener('beforeinstallprompt', (e) => {
            console.log('📱 beforeinstallprompt событие получено');
            e.preventDefault();
            deferredPrompt = e;
            
            // Показываем баннер установки
            this.showInstallBanner();
            
            // Обработка нажатия кнопки установки в баннере
            if (installAppBtn) {
                installAppBtn.onclick = () => {
                    this.hideInstallBanner();
                    deferredPrompt.prompt();
                    
                    deferredPrompt.userChoice.then((choiceResult) => {
                        if (choiceResult.outcome === 'accepted') {
                            console.log('✅ Пользователь установил приложение');
                            this.showNotification('Установлено', 'SecurePass установлен на ваше устройство', 'success');
                        } else {
                            console.log('❌ Пользователь отменил установку');
                        }
                        deferredPrompt = null;
                    });
                };
            }
        });
        
        // App installed event
        window.addEventListener('appinstalled', () => {
            console.log('📱 Приложение установлено');
            deferredPrompt = null;
            this.hideInstallBanner();
            this.checkPWAStatus();
        });
        
        // Обработка ручной установки из меню
        if (installBtnManual) {
            installBtnManual.onclick = () => {
                if (deferredPrompt) {
                    deferredPrompt.prompt();
                    deferredPrompt.userChoice.then((choiceResult) => {
                        if (choiceResult.outcome === 'accepted') {
                            this.showNotification('Установлено', 'SecurePass установлен на ваше устройство', 'success');
                        }
                        deferredPrompt = null;
                    });
                } else {
                    this.showNotification('Информация', 'Используйте меню браузера для установки', 'info');
                }
            };
        }
        
        // Закрытие баннера
        if (dismissBtn) {
            dismissBtn.onclick = () => {
                this.hideInstallBanner();
                localStorage.setItem('pwaBannerDismissed', Date.now().toString());
            };
        }
        
        // Проверяем, нужно ли показывать баннер
        const lastDismissed = localStorage.getItem('pwaBannerDismissed');
        if (lastDismissed) {
            const daysPassed = (Date.now() - parseInt(lastDismissed)) / (1000 * 60 * 60 * 24);
            if (daysPassed < 30) {
                this.hideInstallBanner();
            } else {
                localStorage.removeItem('pwaBannerDismissed');
            }
        }
    },
    
    // Показать баннер установки
    showInstallBanner() {
        const installBanner = document.getElementById('pwaInstallBanner');
        if (installBanner && !localStorage.getItem('pwaBannerDismissed')) {
            installBanner.style.display = 'flex';
            setTimeout(() => {
                installBanner.style.opacity = '1';
                installBanner.style.transform = 'translateY(0)';
            }, 100);
        }
    },
    
    // Скрыть баннер установки
    hideInstallBanner() {
        const installBanner = document.getElementById('pwaInstallBanner');
        if (installBanner) {
            installBanner.style.opacity = '0';
            installBanner.style.transform = 'translateY(-100%)';
            setTimeout(() => {
                installBanner.style.display = 'none';
            }, 300);
        }
    },
    
    // Настройка отслеживания сети
    setupNetworkStatus() {
        window.addEventListener('online', () => {
            this.showNotification('Соединение восстановлено', 'Приложение работает в обычном режиме', 'success');
            document.body.classList.remove('offline');
        });

        window.addEventListener('offline', () => {
            this.showNotification('Нет соединения', 'Приложение работает в автономном режиме', 'warning');
            document.body.classList.add('offline');
        });

        // Проверяем начальный статус
        if (!navigator.onLine) {
            document.body.classList.add('offline');
            this.showNotification('Офлайн режим', 'Нет подключения к интернету', 'warning');
        }
    },
    
    // Загрузка данных из localStorage
    async loadData() {
        try {
            const passwordsData = localStorage.getItem('securePassPasswords');
            const settingsData = localStorage.getItem('securePassSettings');
            const statsData = localStorage.getItem('securePassStats');
            
            if (passwordsData) {
                this.data.passwords = JSON.parse(passwordsData);
            }
            
            if (settingsData) {
                this.data.settings = { ...this.data.settings, ...JSON.parse(settingsData) };
            }
            
            if (statsData) {
                this.data.stats = JSON.parse(statsData);
            }
            
            console.log('📂 Данные загружены:', {
                passwords: this.data.passwords.length,
                settings: this.data.settings,
                stats: this.data.stats
            });
        } catch (error) {
            console.error('❌ Ошибка загрузки данных:', error);
            this.showNotification('Ошибка загрузки', 'Не удалось загрузить сохраненные данные', 'error');
        }
    },
    
    // Сохранение данных в localStorage
    async saveData() {
        try {
            localStorage.setItem('securePassPasswords', JSON.stringify(this.data.passwords));
            localStorage.setItem('securePassSettings', JSON.stringify(this.data.settings));
            localStorage.setItem('securePassStats', JSON.stringify(this.data.stats));
            console.log('💾 Данные сохранены');
        } catch (error) {
            console.error('❌ Ошибка сохранения данных:', error);
        }
    },
    
    // Настройка UI
    setupUI() {
        // Обновление статистики
        this.updatePasswordCount();
        this.updateVaultStats();
        
        // Установка значений по умолчанию
        const lengthValue = document.getElementById('length-value');
        const lengthSlider = document.getElementById('length');
        
        if (lengthValue) lengthValue.textContent = this.config.defaultLength;
        if (lengthSlider) lengthSlider.value = this.config.defaultLength;
        
        // Рендер паролей
        this.renderPasswords();
    },
    
    // Настройка обработчиков событий
    setupEventListeners() {
        // Переключение вкладок
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tabId = e.currentTarget.dataset.tab;
                this.switchTab(tabId);
            });
        });
        
        // Генерация пароля
        const generateBtn = document.getElementById('generate-btn');
        if (generateBtn) {
            generateBtn.addEventListener('click', () => {
                this.generatePassword();
                this.animateButton('generate-btn');
            });
        }
        
        const refreshBtn = document.getElementById('refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.generatePassword();
                this.animateButton('refresh-btn');
            });
        }
        
        // Копирование пароля
        const copyBtn = document.getElementById('copy-btn');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => this.copyPassword());
        }
        
        // Анализ пароля
        const strengthBtn = document.getElementById('strength-btn');
        if (strengthBtn) {
            strengthBtn.addEventListener('click', () => this.showPasswordAnalysis());
        }
        
        // Сохранение пароля
        const saveBtn = document.getElementById('save-btn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.savePassword());
        }
        
        // Изменение настроек
        const lengthSlider = document.getElementById('length');
        if (lengthSlider) {
            lengthSlider.addEventListener('input', (e) => {
                const lengthValue = document.getElementById('length-value');
                if (lengthValue) {
                    lengthValue.textContent = e.target.value;
                }
                this.generatePassword();
            });
        }
        
        document.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            cb.addEventListener('change', () => {
                this.generatePassword();
                this.animateTypeCard(cb.id);
            });
        });
        
        // Клики по карточкам типов символов
        document.querySelectorAll('.type-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.matches('input[type="checkbox"], .switch, .slider')) {
                    const checkbox = card.querySelector('input[type="checkbox"]');
                    if (checkbox) {
                        checkbox.checked = !checkbox.checked;
                        checkbox.dispatchEvent(new Event('change'));
                    }
                }
            });
        });
        
        // Поиск в сейфе
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.state.searchTerm = e.target.value.toLowerCase();
                this.renderPasswords();
            });
        }
        
        const searchClear = document.getElementById('search-clear');
        if (searchClear) {
            searchClear.addEventListener('click', () => {
                const searchInput = document.getElementById('search-input');
                if (searchInput) {
                    searchInput.value = '';
                }
                this.state.searchTerm = '';
                this.renderPasswords();
            });
        }
        
        // Сортировка
        const sortBtn = document.getElementById('sort-btn');
        if (sortBtn) {
            sortBtn.addEventListener('click', () => this.toggleSort());
        }
        
        // Экспорт
        const exportBtn = document.getElementById('export-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportData());
        }
        
        // Резервное копирование
        const backupBtn = document.getElementById('backup-btn');
        if (backupBtn) {
            backupBtn.addEventListener('click', () => this.createBackup());
        }
        
        // Очистка всех данных
        const clearDataBtn = document.getElementById('clear-data');
        if (clearDataBtn) {
            clearDataBtn.addEventListener('click', () => {
                this.showConfirmModal(
                    'Очистить все данные?',
                    'Все сохраненные пароли и настройки будут удалены. Это действие нельзя отменить.',
                    () => this.clearAllData()
                );
            });
        }
        
        // Закрытие модальных окон
        document.querySelectorAll('.modal-close, .modal-overlay').forEach(el => {
            el.addEventListener('click', () => this.closeModal());
        });
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') this.closeModal();
            if (e.key === 'Enter' && e.ctrlKey) this.generatePassword();
        });
        
        // Быстрая генерация по Ctrl+G
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'g') {
                e.preventDefault();
                this.generatePassword();
            }
        });
    },
    
    // Переключение вкладок
    switchTab(tabId) {
        // Обновление активных кнопок
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        const activeTabBtn = document.querySelector(`[data-tab="${tabId}"]`);
        if (activeTabBtn) {
            activeTabBtn.classList.add('active');
        }
        
        // Обновление активного контента
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        const activeTab = document.getElementById(tabId);
        if (activeTab) {
            activeTab.classList.add('active');
            
            // Анимация перехода
            activeTab.style.animation = 'none';
            setTimeout(() => {
                activeTab.style.animation = 'slideUp 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
            }, 10);
        }
        
        // Обновление статистики для вкладки сейфа
        if (tabId === 'vault') {
            this.updateVaultStats();
        }
    },
    
    // Генерация пароля
    generatePassword() {
        const length = parseInt(document.getElementById('length').value);
        const includeUpper = document.getElementById('uppercase').checked;
        const includeLower = document.getElementById('lowercase').checked;
        const includeNumbers = document.getElementById('numbers').checked;
        const includeSymbols = document.getElementById('symbols').checked;
        
        // Проверка выбора символов
        if (!includeUpper && !includeLower && !includeNumbers && !includeSymbols) {
            this.showNotification('Внимание', 'Выберите хотя бы один тип символов', 'warning');
            const output = document.getElementById('password-output');
            if (output) {
                output.value = 'Выберите тип символов';
            }
            return;
        }
        
        // Наборы символов
        const charSets = {
            upper: 'ABCDEFGHJKLMNPQRSTUVWXYZ',
            lower: 'abcdefghijkmnpqrstuvwxyz',
            numbers: '23456789',
            symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?'
        };
        
        // Сбор доступных символов
        let availableChars = '';
        const guaranteedChars = [];
        
        if (includeUpper) {
            availableChars += charSets.upper;
            guaranteedChars.push(this.getRandomChar(charSets.upper));
        }
        
        if (includeLower) {
            availableChars += charSets.lower;
            guaranteedChars.push(this.getRandomChar(charSets.lower));
        }
        
        if (includeNumbers) {
            availableChars += charSets.numbers;
            guaranteedChars.push(this.getRandomChar(charSets.numbers));
        }
        
        if (includeSymbols) {
            availableChars += charSets.symbols;
            guaranteedChars.push(this.getRandomChar(charSets.symbols));
        }
        
        // Генерация оставшихся символов
        const remainingLength = length - guaranteedChars.length;
        for (let i = 0; i < remainingLength; i++) {
            guaranteedChars.push(this.getRandomChar(availableChars));
        }
        
        // Перемешивание массива
        const password = this.shuffleArray(guaranteedChars).join('');
        
        // Сохранение и отображение
        this.state.currentPassword = password;
        const output = document.getElementById('password-output');
        if (output) {
            output.value = password;
        }
        
        const passwordLength = document.getElementById('password-length');
        if (passwordLength) {
            passwordLength.textContent = `${length} символов`;
        }
        
        // Обновление статистики
        this.data.stats.generated++;
        this.saveData();
        
        // Анализ сложности
        this.updatePasswordStrength(password);
        
        // Анимация
        this.animatePasswordGeneration();
        
        console.log('🔑 Сгенерирован пароль');
    },
    
    // Получение случайного символа
    getRandomChar(charSet) {
        // Используем Web Crypto API если доступен
        if (window.crypto && window.crypto.getRandomValues) {
            const randomArray = new Uint32Array(1);
            window.crypto.getRandomValues(randomArray);
            return charSet[randomArray[0] % charSet.length];
        }
        
        // Fallback для старых браузеров
        return charSet[Math.floor(Math.random() * charSet.length)];
    },
    
    // Перемешивание массива
    shuffleArray(array) {
        const newArray = [...array];
        for (let i = newArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
        }
        return newArray;
    },
    
    // Анимация генерации пароля
    animatePasswordGeneration() {
        const output = document.getElementById('password-output');
        if (!output) return;
        
        const chars = output.value.split('');
        
        // Эффект появления символов по одному
        output.value = '';
        
        chars.forEach((char, index) => {
            setTimeout(() => {
                output.value += char;
                output.style.boxShadow = `0 0 ${20 + index * 2}px rgba(79, 195, 247, 0.5)`;
                
                if (index === chars.length - 1) {
                    setTimeout(() => {
                        output.style.boxShadow = '';
                    }, 500);
                }
            }, index * 50);
        });
        
        // Анимация кнопки генерации
        const btn = document.getElementById('generate-btn');
        if (btn) {
            btn.style.animation = 'none';
            setTimeout(() => {
                btn.style.animation = 'pulse 0.5s';
            }, 10);
        }
    },
    
    // Анимация карточки типа символов
    animateTypeCard(type) {
        const card = document.querySelector(`[data-type="${type}"]`);
        if (!card) return;
        
        card.style.transform = 'scale(0.95)';
        card.style.boxShadow = '0 0 30px rgba(79, 195, 247, 0.5)';
        
        setTimeout(() => {
            card.style.transform = '';
            card.style.boxShadow = '';
        }, 300);
    },
    
    // Анимация кнопки
    animateButton(buttonId) {
        const button = document.getElementById(buttonId);
        if (!button) return;
        
        button.style.transform = 'scale(0.95)';
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 150);
    },
    
    // Копирование пароля
    async copyPassword() {
        if (!this.state.currentPassword) {
            this.showNotification('Внимание', 'Сначала сгенерируйте пароль', 'warning');
            return;
        }
        
        try {
            await navigator.clipboard.writeText(this.state.currentPassword);
            
            // Обновление статистики
            this.data.stats.copied++;
            this.saveData();
            
            // Анимация успеха
            const btn = document.getElementById('copy-btn');
            if (btn) {
                const icon = btn.querySelector('i');
                if (icon) {
                    const originalIcon = icon.className;
                    icon.className = 'fas fa-check';
                    btn.style.background = 'linear-gradient(135deg, #4CAF50, #2E7D32)';
                    btn.style.transform = 'scale(1.1)';
                    
                    setTimeout(() => {
                        icon.className = originalIcon;
                        btn.style.background = '';
                        btn.style.transform = '';
                    }, 2000);
                }
            }
            
            this.showNotification('Успех', 'Пароль скопирован в буфер обмена', 'success');
            
            console.log('📋 Пароль скопирован');
        } catch (error) {
            console.error('❌ Ошибка копирования:', error);
            // Fallback для старых браузеров
            const textArea = document.createElement('textarea');
            textArea.value = this.state.currentPassword;
            document.body.appendChild(textArea);
            textArea.select();
            try {
                document.execCommand('copy');
                this.showNotification('Успех', 'Пароль скопирован в буфер обмена', 'success');
            } catch (err) {
                this.showNotification('Ошибка', 'Не удалось скопировать пароль', 'error');
            }
            document.body.removeChild(textArea);
        }
    },
    
    // Анализ пароля
    analyzePassword(password) {
        const analysis = {
            length: password.length,
            hasUpper: /[A-Z]/.test(password),
            hasLower: /[a-z]/.test(password),
            hasNumbers: /[0-9]/.test(password),
            hasSymbols: /[^A-Za-z0-9]/.test(password),
            entropy: 0,
            score: 0,
            strength: 'weak'
        };
        
        // Расчет энтропии
        let charPool = 0;
        if (analysis.hasUpper) charPool += 26;
        if (analysis.hasLower) charPool += 26;
        if (analysis.hasNumbers) charPool += 10;
        if (analysis.hasSymbols) charPool += 32;
        
        if (charPool > 0) {
            analysis.entropy = Math.log2(Math.pow(charPool, password.length));
        }
        
        // Расчет оценки
        let score = 0;
        
        // Баллы за длину
        if (password.length >= 8) score += 20;
        if (password.length >= 12) score += 15;
        if (password.length >= 16) score += 10;
        if (password.length >= 20) score += 5;
        
        // Баллы за сложность
        const complexityFactors = [
            analysis.hasUpper,
            analysis.hasLower,
            analysis.hasNumbers,
            analysis.hasSymbols
        ];
        
        const activeFactors = complexityFactors.filter(Boolean).length;
        score += activeFactors * 15;
        
        // Бонус за уникальность
        const uniqueChars = new Set(password).size;
        score += (uniqueChars / password.length) * 20;
        
        // Ограничение оценки
        analysis.score = Math.min(Math.round(score), 100);
        
        // Определение силы
        if (analysis.score >= 80) analysis.strength = 'very-strong';
        else if (analysis.score >= 60) analysis.strength = 'strong';
        else if (analysis.score >= 40) analysis.strength = 'medium';
        else analysis.strength = 'weak';
        
        return analysis;
    },
    
    // Обновление индикатора сложности
    updatePasswordStrength(password) {
        const analysis = this.analyzePassword(password);
        
        // Обновление числовой оценки
        const strengthValue = document.getElementById('strength-value');
        if (strengthValue) {
            strengthValue.textContent = analysis.score;
        }
        
        // Обновление полосы
        const fill = document.getElementById('strength-fill');
        if (fill) {
            fill.style.width = `${analysis.score}%`;
            fill.style.background = `linear-gradient(90deg, #f44336, #ff9800, #4caf50, #2196f3)`;
            fill.style.backgroundSize = `${analysis.score}% 100%`;
        }
        
        // Обновление текста
        const feedback = document.getElementById('strength-feedback');
        if (feedback) {
            let message = '';
            let icon = 'fa-check-circle';
            
            if (analysis.score >= 80) {
                message = 'Отличный пароль! Высокий уровень безопасности.';
                icon = 'fa-check-circle';
            } else if (analysis.score >= 60) {
                message = 'Хороший пароль. Можно добавить больше символов.';
                icon = 'fa-check-circle';
            } else if (analysis.score >= 40) {
                message = 'Средний пароль. Рекомендуем увеличить длину.';
                icon = 'fa-exclamation-triangle';
            } else {
                message = 'Слабый пароль. Добавьте разные типы символов.';
                icon = 'fa-exclamation-triangle';
            }
            
            feedback.innerHTML = `<i class="fas ${icon}"></i><span>${message}</span>`;
        }
    },
    
    // Показать анализ пароля
    showPasswordAnalysis() {
        if (!this.state.currentPassword) {
            this.showNotification('Внимание', 'Сначала сгенерируйте пароль', 'warning');
            return;
        }
        
        const analysis = this.analyzePassword(this.state.currentPassword);
        
        // Обновление модального окна
        const analysisScore = document.getElementById('analysis-score');
        if (analysisScore) {
            analysisScore.textContent = analysis.score;
        }
        
        const analysisText = document.getElementById('analysis-text');
        if (analysisText) {
            analysisText.textContent = 
                analysis.score >= 80 ? 'Очень сильный пароль' :
                analysis.score >= 60 ? 'Сильный пароль' :
                analysis.score >= 40 ? 'Средний пароль' : 'Слабый пароль';
        }
        
        const lengthValueModal = document.getElementById('length-value-modal');
        if (lengthValueModal) {
            lengthValueModal.textContent = `${analysis.length} символов`;
        }
        
        const complexityValue = document.getElementById('complexity-value');
        if (complexityValue) {
            complexityValue.textContent = 
                analysis.hasUpper && analysis.hasLower && analysis.hasNumbers && analysis.hasSymbols ? 
                'Высокая' : 'Средняя';
        }
        
        const entropyValue = document.getElementById('entropy-value');
        if (entropyValue) {
            entropyValue.textContent = `${Math.round(analysis.entropy)} бит`;
        }
        
        // Обновление полос
        const lengthBar = document.getElementById('length-bar');
        if (lengthBar) {
            lengthBar.style.width = `${Math.min(analysis.length * 5, 100)}%`;
        }
        
        const complexityBar = document.getElementById('complexity-bar');
        if (complexityBar) {
            complexityBar.style.width = `${analysis.score}%`;
        }
        
        const entropyBar = document.getElementById('entropy-bar');
        if (entropyBar) {
            entropyBar.style.width = `${Math.min(analysis.entropy / 2, 100)}%`;
        }
        
        // Обновление рекомендаций
        const recommendations = document.getElementById('recommendations-list');
        if (recommendations) {
            recommendations.innerHTML = '';
            
            const tips = [];
            
            if (analysis.length < 12) {
                tips.push('Увеличьте длину пароля до 12+ символов');
            }
            
            if (!analysis.hasUpper || !analysis.hasLower || !analysis.hasNumbers || !analysis.hasSymbols) {
                tips.push('Используйте все типы символов');
            }
            
            if (tips.length === 0) {
                tips.push('✓ Пароль соответствует рекомендациям');
                tips.push('✓ Хорошая длина и сложность');
                tips.push('✓ Высокая энтропия');
            }
            
            tips.forEach(tip => {
                const li = document.createElement('li');
                li.textContent = tip;
                recommendations.appendChild(li);
            });
        }
        
        // Показать модальное окно
        this.showModal('password-modal');
    },
    
    // Сохранение пароля
    async savePassword() {
        const siteNameInput = document.getElementById('site-name');
        const usernameInput = document.getElementById('username');
        
        if (!siteNameInput || !usernameInput) return;
        
        const siteName = siteNameInput.value.trim();
        const username = usernameInput.value.trim();
        
        if (!siteName || !username) {
            this.showNotification('Внимание', 'Заполните все поля', 'warning');
            return;
        }
        
        if (!this.state.currentPassword) {
            this.showNotification('Внимание', 'Сначала сгенерируйте пароль', 'warning');
            return;
        }
        
        // Проверка на дубликаты
        const duplicateIndex = this.data.passwords.findIndex(p => 
            p.siteName.toLowerCase() === siteName.toLowerCase() && 
            p.username.toLowerCase() === username.toLowerCase()
        );
        
        if (duplicateIndex !== -1) {
            this.showConfirmModal(
                'Пароль уже существует',
                `Пароль для "${siteName}" с именем пользователя "${username}" уже существует. Заменить?`,
                () => this.savePasswordConfirmed(siteName, username, duplicateIndex)
            );
            return;
        }
        
        this.savePasswordConfirmed(siteName, username);
    },
    
    // Подтвержденное сохранение пароля
    savePasswordConfirmed(siteName, username, duplicateIndex = -1) {
        const siteNameInput = document.getElementById('site-name');
        const usernameInput = document.getElementById('username');
        
        const analysis = this.analyzePassword(this.state.currentPassword);
        
        const passwordData = {
            id: Date.now() + Math.random(),
            siteName,
            username,
            password: this.state.currentPassword,
            strength: analysis.score,
            strengthLevel: analysis.strength,
            length: this.state.currentPassword.length,
            date: new Date().toISOString(),
            lastUsed: new Date().toISOString()
        };
        
        // Удаляем дубликат, если он есть
        if (duplicateIndex !== -1) {
            this.data.passwords.splice(duplicateIndex, 1);
        }
        
        // Добавление в начало массива
        this.data.passwords.unshift(passwordData);
        
        // Ограничение количества паролей
        if (this.data.passwords.length > this.config.maxPasswords) {
            this.data.passwords = this.data.passwords.slice(0, this.config.maxPasswords);
        }
        
        // Сохранение данных
        this.saveData();
        
        // Обновление UI
        this.updatePasswordCount();
        this.updateVaultStats();
        this.renderPasswords();
        
        // Очистка формы
        if (siteNameInput) siteNameInput.value = '';
        if (usernameInput) usernameInput.value = '';
        
        // Анимация успеха
        const btn = document.getElementById('save-btn');
        if (btn) {
            btn.innerHTML = '<i class="fas fa-check"></i><span>Сохранено!</span>';
            btn.style.background = 'linear-gradient(135deg, #4CAF50, #2E7D32)';
            
            setTimeout(() => {
                btn.innerHTML = '<i class="fas fa-lock"></i><span>Сохранить пароль</span>';
                btn.style.background = '';
            }, 2000);
        }
        
        this.showNotification('Успех', 'Пароль сохранен в сейфе', 'success');
        this.data.stats.saved++;
        
        console.log('💾 Пароль сохранен');
    },
    
    // Обновление счетчика паролей
    updatePasswordCount() {
        const savedCount = document.getElementById('saved-count');
        if (savedCount) {
            savedCount.textContent = this.data.passwords.length;
        }
    },
    
    // Обновление статистики сейфа
    updateVaultStats() {
        const total = this.data.passwords.length;
        const strong = this.data.passwords.filter(p => p.strength >= 60).length;
        const weak = this.data.passwords.filter(p => p.strength < 40).length;
        
        // Последние 30 дней
        const monthAgo = new Date();
        monthAgo.setDate(monthAgo.getDate() - 30);
        const recent = this.data.passwords.filter(p => 
            new Date(p.date) > monthAgo
        ).length;
        
        const totalPasswords = document.getElementById('total-passwords');
        const strongPasswords = document.getElementById('strong-passwords');
        const weakPasswords = document.getElementById('weak-passwords');
        const recentPasswords = document.getElementById('recent-passwords');
        
        if (totalPasswords) totalPasswords.textContent = total;
        if (strongPasswords) strongPasswords.textContent = strong;
        if (weakPasswords) weakPasswords.textContent = weak;
        if (recentPasswords) recentPasswords.textContent = recent;
    },
    
    // Обновление общей статистики
    updateStats() {
        console.log('📊 Статистика:', this.data.stats);
    },
    
    // Отображение списка паролей
    renderPasswords() {
        const container = document.getElementById('passwords-list');
        if (!container) return;
        
        // Фильтрация и сортировка
        let filteredPasswords = [...this.data.passwords];
        
        // Поиск
        if (this.state.searchTerm) {
            filteredPasswords = filteredPasswords.filter(p => 
                p.siteName.toLowerCase().includes(this.state.searchTerm) ||
                p.username.toLowerCase().includes(this.state.searchTerm)
            );
        }
        
        // Сортировка
        filteredPasswords.sort((a, b) => {
            let aValue, bValue;
            
            switch (this.state.sortBy) {
                case 'name':
                    aValue = a.siteName.toLowerCase();
                    bValue = b.siteName.toLowerCase();
                    break;
                case 'strength':
                    aValue = a.strength;
                    bValue = b.strength;
                    break;
                case 'date':
                default:
                    aValue = new Date(a.date);
                    bValue = new Date(b.date);
                    break;
            }
            
            if (this.state.sortOrder === 'asc') {
                return aValue > bValue ? 1 : -1;
            } else {
                return aValue < bValue ? 1 : -1;
            }
        });
        
        // Отрисовка
        if (filteredPasswords.length === 0) {
            container.innerHTML = `
                <div class="empty-state animate__animated animate__fadeIn">
                    <div class="empty-icon">
                        <i class="fas fa-lock-open"></i>
                        <div class="empty-glow"></div>
                    </div>
                    <h3>${this.state.searchTerm ? 'Ничего не найдено' : 'Ваш сейф пуст'}</h3>
                    <p>${this.state.searchTerm ? 'Попробуйте другой поисковый запрос' : 'Начните с сохранения первого пароля'}</p>
                    <button class="btn-primary" onclick="SecurePass.switchTab('generator')">
                        <i class="fas fa-plus"></i> Создать пароль
                    </button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = filteredPasswords.map(password => `
            <div class="password-item glass ${password.strengthLevel}" data-id="${password.id}">
                <div class="password-header">
                    <div class="site-name">${this.escapeHtml(password.siteName)}</div>
                    <div class="password-actions">
                        <button class="btn-icon show-password" title="Показать/скрыть пароль" data-id="${password.id}">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-icon copy-item" title="Копировать пароль" data-id="${password.id}">
                            <i class="far fa-copy"></i>
                        </button>
                        <button class="btn-icon delete-item" title="Удалить" data-id="${password.id}">
                            <i class="far fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
                <div class="password-details">
                    <div class="detail-item">
                        <label>Имя пользователя:</label>
                        <input type="text" value="${this.escapeHtml(password.username)}" readonly>
                    </div>
                    <div class="detail-item">
                        <label>Пароль:</label>
                        <input type="password" value="${this.escapeHtml(password.password)}" 
                               class="password-field" data-id="${password.id}" readonly>
                    </div>
                </div>
                <div class="password-meta">
                    <div class="password-strength">
                        <div class="strength-dot" style="background: ${this.getStrengthColor(password.strength)}"></div>
                        <span>${password.strength}/100</span>
                    </div>
                    <div class="password-date">${new Date(password.date).toLocaleDateString('ru-RU')}</div>
                </div>
            </div>
        `).join('');
        
        // Добавление обработчиков событий
        this.attachPasswordEventListeners();
    },
    
    // Прикрепление обработчиков событий к паролям
    attachPasswordEventListeners() {
        // Показать/скрыть пароль
        document.querySelectorAll('.show-password').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.dataset.id;
                const passwordField = document.querySelector(`.password-field[data-id="${id}"]`);
                const icon = btn.querySelector('i');
                
                if (passwordField && icon) {
                    if (passwordField.type === 'password') {
                        passwordField.type = 'text';
                        icon.className = 'fas fa-eye-slash';
                        
                        // Автоматическое скрытие через 10 секунд
                        setTimeout(() => {
                            if (passwordField.type === 'text') {
                                passwordField.type = 'password';
                                icon.className = 'fas fa-eye';
                            }
                        }, 10000);
                    } else {
                        passwordField.type = 'password';
                        icon.className = 'fas fa-eye';
                    }
                }
            });
        });
        
        // Копирование пароля из сейфа
        document.querySelectorAll('.copy-item').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = e.currentTarget.dataset.id;
                const passwordField = document.querySelector(`.password-field[data-id="${id}"]`);
                if (!passwordField) return;
                
                const password = passwordField.value;
                
                try {
                    await navigator.clipboard.writeText(password);
                    
                    // Обновление статистики
                    this.data.stats.copied++;
                    this.saveData();
                    
                    // Анимация успеха
                    const icon = btn.querySelector('i');
                    if (icon) {
                        const originalIcon = icon.className;
                        icon.className = 'fas fa-check';
                        btn.style.background = 'linear-gradient(135deg, #4CAF50, #2E7D32)';
                        
                        this.showNotification('Успех', 'Пароль скопирован', 'success');
                        
                        setTimeout(() => {
                            icon.className = originalIcon;
                            btn.style.background = '';
                        }, 2000);
                    }
                } catch (error) {
                    // Fallback
                    const textArea = document.createElement('textarea');
                    textArea.value = password;
                    document.body.appendChild(textArea);
                    textArea.select();
                    try {
                        document.execCommand('copy');
                        this.showNotification('Успех', 'Пароль скопирован', 'success');
                    } catch (err) {
                        this.showNotification('Ошибка', 'Не удалось скопировать пароль', 'error');
                    }
                    document.body.removeChild(textArea);
                }
            });
        });
        
        // Удаление пароля
        document.querySelectorAll('.delete-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.dataset.id;
                const password = this.data.passwords.find(p => p.id == id);
                
                if (password) {
                    this.showConfirmModal(
                        'Удалить пароль?',
                        `Вы уверены, что хотите удалить пароль для "${password.siteName}"?`,
                        () => this.deletePassword(id)
                    );
                }
            });
        });
    },
    
    // Удаление пароля
    deletePassword(id) {
        this.data.passwords = this.data.passwords.filter(p => p.id != id);
        this.saveData();
        this.updatePasswordCount();
        this.updateVaultStats();
        this.renderPasswords();
        
        this.showNotification('Удалено', 'Пароль удален из сейфа', 'info');
    },
    
    // Переключение сортировки
    toggleSort() {
        const sortOptions = ['date', 'name', 'strength'];
        const currentIndex = sortOptions.indexOf(this.state.sortBy);
        const nextIndex = (currentIndex + 1) % sortOptions.length;
        
        this.state.sortBy = sortOptions[nextIndex];
        this.state.sortOrder = this.state.sortOrder === 'asc' ? 'desc' : 'asc';
        
        // Обновление иконки кнопки
        const btn = document.getElementById('sort-btn');
        if (btn) {
            const icon = btn.querySelector('i');
            if (icon) {
                const icons = {
                    'date': 'fa-sort-amount-down',
                    'name': 'fa-sort-alpha-down',
                    'strength': 'fa-sort-numeric-down'
                };
                
                icon.className = `fas ${icons[this.state.sortBy]}`;
                
                if (this.state.sortOrder === 'asc') {
                    btn.style.transform = 'rotate(180deg)';
                } else {
                    btn.style.transform = 'rotate(0deg)';
                }
            }
        }
        
        this.renderPasswords();
        this.showNotification('Сортировка', `Сортировка по: ${this.getSortLabel(this.state.sortBy)}`, 'info');
    },
    
    // Получение метки сортировки
    getSortLabel(sortBy) {
        const labels = {
            'date': 'дате',
            'name': 'названию',
            'strength': 'сложности'
        };
        return labels[sortBy] || sortBy;
    },
    
    // Экспорт данных
    exportData() {
        const data = {
            version: this.config.version,
            exportedAt: new Date().toISOString(),
            passwords: this.data.passwords,
            stats: this.data.stats
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `securepass-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        
        this.showNotification('Экспорт', 'Резервная копия создана', 'success');
    },
    
    // Создание резервной копии
    createBackup() {
        this.exportData();
    },
    
    // Очистка всех данных
    clearAllData() {
        this.data.passwords = [];
        this.data.stats = {
            generated: 0,
            saved: 0,
            copied: 0
        };
        
        this.saveData();
        this.updatePasswordCount();
        this.updateVaultStats();
        this.renderPasswords();
        
        this.showNotification('Очищено', 'Все данные удалены', 'info');
        this.closeModal();
    },
    
    // Получение цвета для силы пароля
    getStrengthColor(strength) {
        if (strength >= 80) return '#2196f3';
        if (strength >= 60) return '#4caf50';
        if (strength >= 40) return '#ff9800';
        return '#f44336';
    },
    
    // Экранирование HTML
    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    
    // Показать модальное окно
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'flex';
            setTimeout(() => {
                modal.style.opacity = '1';
            }, 10);
        }
    },
    
    // Закрыть модальное окно
    closeModal() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.opacity = '0';
            setTimeout(() => {
                modal.style.display = 'none';
            }, 300);
        });
    },
    
    // Показать окно подтверждения
    showConfirmModal(title, message, confirmCallback) {
        const modalMessage = document.getElementById('modal-message');
        if (modalMessage) {
            modalMessage.textContent = message;
        }
        
        const modal = document.getElementById('confirm-modal');
        if (!modal) return;
        
        modal.style.display = 'flex';
        
        const confirmBtn = document.getElementById('modal-confirm');
        const cancelBtn = document.getElementById('modal-cancel');
        
        // Временные обработчики
        const handleConfirm = () => {
            confirmCallback();
            this.closeModal();
            cleanup();
        };
        
        const handleCancel = () => {
            this.closeModal();
            cleanup();
        };
        
        const cleanup = () => {
            confirmBtn.removeEventListener('click', handleConfirm);
            cancelBtn.removeEventListener('click', handleCancel);
        };
        
        confirmBtn.addEventListener('click', handleConfirm);
        cancelBtn.addEventListener('click', handleCancel);
        
        setTimeout(() => {
            modal.style.opacity = '1';
        }, 10);
    },
    
    // Показать уведомление
    showNotification(title, message, type = 'info') {
        const container = document.getElementById('notification-container');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        let icon = 'fa-info-circle';
        switch (type) {
            case 'success': icon = 'fa-check-circle'; break;
            case 'error': icon = 'fa-exclamation-circle'; break;
            case 'warning': icon = 'fa-exclamation-triangle'; break;
        }
        
        notification.innerHTML = `
            <i class="fas ${icon}"></i>
            <div class="notification-content">
                <div class="notification-title">${title}</div>
                <div class="notification-message">${message}</div>
            </div>
        `;
        
        container.appendChild(notification);
        
        // Автоматическое удаление через 3 секунды
        setTimeout(() => {
            notification.style.animation = 'fadeOut 0.3s';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    },
    
    // Создание частиц
    createParticles() {
        const particlesContainer = document.getElementById('particles');
        if (!particlesContainer) return;
        
        const particleCount = 50;
        
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            // Случайная позиция
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.top = `${Math.random() * 100}%`;
            
            // Случайный размер
            const size = Math.random() * 3 + 1;
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            
            // Случайная прозрачность
            particle.style.opacity = Math.random() * 0.3 + 0.1;
            
            // Случайная задержка анимации
            particle.style.animationDelay = `${Math.random() * 20}s`;
            particle.style.animationDuration = `${Math.random() * 10 + 15}s`;
            
            particlesContainer.appendChild(particle);
        }
    },
    
    // Запуск анимаций
    startAnimations() {
        // Анимация логотипа
        const logoIcon = document.querySelector('.logo-icon i');
        if (logoIcon) {
            setInterval(() => {
                logoIcon.style.transform = 'scale(1.2)';
                logoIcon.style.color = '#4fc3f7';
                
                setTimeout(() => {
                    logoIcon.style.transform = 'scale(1)';
                    logoIcon.style.color = '#4fc3f7';
                }, 300);
            }, 5000);
        }
        
        // Анимация свечения кнопок
        const sparkleButtons = document.querySelectorAll('.btn-glow');
        sparkleButtons.forEach(btn => {
            const sparkle = btn.querySelector('.btn-sparkle');
            if (sparkle) {
                sparkle.style.setProperty('--x', `${Math.random() * 40 - 20}px`);
                sparkle.style.setProperty('--y', `${Math.random() * 40 - 20}px`);
            }
        });
    }
};

// Инициализация приложения
document.addEventListener('DOMContentLoaded', () => {
    SecurePass.init();
    
    // Добавление задержек для анимаций
    document.querySelectorAll('.animate__animated').forEach((el, index) => {
        el.style.animationDelay = `${index * 0.1}s`;
    });
    
    // Запуск анимации частиц
    setTimeout(() => {
        document.querySelectorAll('.particle').forEach(particle => {
            particle.style.animationPlayState = 'running';
        });
    }, 1000);
});

// Глобальные хоткеи
document.addEventListener('keydown', (e) => {
    // Ctrl+Shift+G - быстрая генерация и копирование
    if (e.ctrlKey && e.shiftKey && e.key === 'G') {
        e.preventDefault();
        SecurePass.generatePassword();
        setTimeout(() => SecurePass.copyPassword(), 100);
    }
    
    // Ctrl+Shift+S - сохранение пароля
    if (e.ctrlKey && e.shiftKey && e.key === 'S') {
        e.preventDefault();
        const saveBtn = document.getElementById('save-btn');
        if (saveBtn) saveBtn.click();
    }
    
    // Ctrl+Shift+C - открытие сейфа
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
        e.preventDefault();
        SecurePass.switchTab('vault');
    }
});

// Обработка онлайн/офлайн статуса
window.addEventListener('online', () => {
    SecurePass.showNotification('Соединение восстановлено', 'Приложение работает в обычном режиме', 'success');
});

window.addEventListener('offline', () => {
    SecurePass.showNotification('Нет соединения', 'Приложение работает в автономном режиме', 'warning');
});

// Сохранение данных перед закрытием страницы
window.addEventListener('beforeunload', () => {
    SecurePass.saveData();
});