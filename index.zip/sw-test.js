// Простейший Service Worker для теста
const CACHE_NAME = 'securepass-test-v1';

self.addEventListener('install', event => {
  console.log('🔧 Service Worker: Установка');
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  console.log('⚡ Service Worker: Активация');
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  event.respondWith(fetch(event.request));
});